def spotify_playlists():
    playlists = {'rap_caviar': 'spotify:playlist:37i9dQZF1DXaVgr4Tx5kRF'}
    return playlists
